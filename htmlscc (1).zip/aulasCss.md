/* AULA CSS - UDEMY:;
CSS:  arquivo de formatação do html.

EFEITO CASCATA(ORDEM DE PRIORIDADE - MENOR PARA O MAIOR):
1. ESTILO EXTERNO (IMPORTADO);
2. ESTILO INCORPORADO (DEFINIDO NO head);
3. ESTILO INLINE (DENTRO DE UM ELEMENTO).

MARCAÇÃO !important; - prioridade sobre todas as outras tag´s

AULAS: ;

6. SELETORES = elementos de marcação do HTML(tag´s): (REGRA BÁSICA):

    seletor{
        propriedade:  valor;
    }

7. PROPRIEDADE: COLOR - colorindo o HTML: 
    
    7.1. COLORIR UM PARÁGRAFO <P>:

    p{
        color:  red; // colorir o texto de um parágrafo.
        color:  #990000; // utilizando um valor de RGB:  CADA PAR DE NUMERO REPRESENTA red+green+blue.
        background-color: green; // ALTERA A COR DA LINHA DO PARÁGRAFO.
        background-color: #000000; // ALTERA A COR DA LINHA DO PARÁGRAFO.
        font-size: 90px;  // aumenta o tamanho da fonte: - valor em px:  90 px;
        font-family: impact; // altera o tipo de fonte. pode ser declarada 2 fontes; se não tiver instalada a  1, utiliza a 2. 
    }

8. DIV´s: A PÁGINA JÁ É CONFIGURADA COM ESPAÇAMENTO PADRÃO, ENTÃO: ;
PARA REMOVER OS ESPAÇAMENTO PADRÃO: 
*{
    margin:  0;
    padding: 0;
}

9 .CONTAINER:



* /

    


